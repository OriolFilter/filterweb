create function func_return_activation_code(p_username character varying) returns character varying
    language plpgsql
as
$$
declare
    v_uid integer;
    v_string varchar(60);
begin
    /*get uid then call the other command*/
    case when not exists(select user_id from users where lower(username)=lower(p_username))
        then raise exception
        using errcode = 'P6201',
            message = 'The given username wasn''t found';
        else
            select into v_uid user_id from users where lower(username)=lower(p_username);
    end case;
    select into v_string func_return_activation_code(v_uid);
    return v_string;


end;
$$;

alter function func_return_activation_code(varchar) owner to test;

