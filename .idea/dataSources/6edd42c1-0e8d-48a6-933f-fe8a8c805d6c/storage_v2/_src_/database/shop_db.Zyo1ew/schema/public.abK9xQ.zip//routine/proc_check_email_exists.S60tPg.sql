create procedure proc_check_email_exists(p_email character varying)
    language plpgsql
as
$$
begin
    case when exists(select lower(email) from users where lower(email)=lower(p_email))
        then raise exception
            using errcode = 'P6102',
                message = 'This email is already in use';
        else null;
    end case;
end;
$$;

alter procedure proc_check_email_exists(varchar) owner to test;

