create procedure check_shipping_address_l3(p_name_method character varying)
    language plpgsql
as
$$
begin
    /* 5 - 200 chars - empty */
    if ((length(p_name_method::varchar) < 5 or length(p_name_method::varchar) > 200) and (not length(p_name_method::varchar) is null and not length(p_name_method::varchar) = 0) ) then
        raise exception
            using errcode = 'P3906',
                message = 'Shipping address line 3 field does not meet the requirements',
                hint = 'Shipping address line 3 needs to be from 5 to 200 or empty';
    end if;
end;
$$;

alter procedure check_shipping_address_l3(varchar) owner to test;

