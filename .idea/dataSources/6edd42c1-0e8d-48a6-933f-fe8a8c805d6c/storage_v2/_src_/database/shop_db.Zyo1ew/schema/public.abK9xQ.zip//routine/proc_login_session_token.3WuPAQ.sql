create procedure proc_login_session_token(p_token character varying)
    language plpgsql
as
$$
begin /* Login with session token */
        call proc_check_session_token_is_valid(p_token);
        call proc_enlarge_login(p_token);
        update users set last_login=now() from users u,session_tokens s where u.user_id=s.user_id and s.session_token=p_token; /* No need to check token is valid due proc */
--         update session_tokens set expires_on=now() + '30 minute'::interval where session_token=p_token;
    end;
$$;

alter procedure proc_login_session_token(varchar) owner to test;

