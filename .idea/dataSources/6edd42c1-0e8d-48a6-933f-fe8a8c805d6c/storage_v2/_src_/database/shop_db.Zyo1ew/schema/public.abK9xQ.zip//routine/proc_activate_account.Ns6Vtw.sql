create procedure proc_activate_account(p_token character varying)
    language plpgsql
as
$$
declare
    u_id integer;
begin
    -- Working with activation tokens
    -- P0040 token null
    -- P0041 not found in the database/valid
    -- P0042 token expired
    -- P0043 token used
    -- P0044 user already enabled
    if p_token='' then
        raise exception
            using errcode = 'P6304',
                message = 'Token is null or empty';
    end if;
    case when not exists(select true from activate_account_tokens where activation_account_token=p_token)
        then raise exception
            using errcode = 'P6204',
                message = 'Token not found';
        else null;
        end case;
    case when not exists(select true from activate_account_tokens where activation_account_token=p_token and created_on<now() and expires_on>now())
        then raise exception
            using errcode = 'P6302',
                message = 'The token expired';
        else null;
        end case;
    case when not exists(select true from activate_account_tokens where activation_account_token=p_token and used_bool=false)
        then raise exception
            using errcode = 'P6303',
                message = 'The token already used';
        else null;
        end case;
    case when not exists(select true from activate_account_tokens aat, activated_accounts aa where aat.activation_account_token=p_token and aa.user_id=aat.user_id)
        then raise exception
            using errcode = 'P7100',
                message = 'The user is already enabled';
        else null;
        end case;

    select into u_id user_id from activate_account_tokens where activation_account_token=p_token;
    update activate_account_tokens set used_bool=true where activation_account_token=p_token;
    update activated_accounts aa set activated_bool=true,activation_date=now() where u_id=aa.user_id;
end;
$$;

alter procedure proc_activate_account(varchar) owner to test;

