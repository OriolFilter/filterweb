create procedure proc_change_password_user(p_token character varying, p_pass character varying)
    language plpgsql
as
$$
declare
        v_uid integer;
    begin
        call proc_check_password_token_is_valid(p_token);
        select into v_uid user_id from change_password_tokens where change_password_token=p_token;
        update users set password=return_crypted_pass(p_pass) where user_id=v_uid;
        update change_password_tokens set used_bool=true where change_password_token=p_token;

end;
$$;

alter procedure proc_change_password_user(varchar, varchar) owner to test;

