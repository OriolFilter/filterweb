create procedure proc_generate_activation_code(p_uid integer)
    language plpgsql
as
$$
declare
    v_string varchar(60);
begin
    /*check user not enabled*/
    case when exists(select true from activated_accounts where user_id=p_uid and activated_bool=true)
        then raise exception
            using errcode = 'P7200',
                message = 'This account is already activated';
        else null;
    end case;
    select into v_string random_string(60);
    while (select true from activate_account_tokens where activation_account_token=v_string) loop
            select into v_string random_string(60);
        end loop;
    insert into activate_account_tokens(user_id,activation_account_token) values(p_uid,v_string);
exception
    when sqlstate '23503' then
        raise exception
            using errcode = 'P6210',
                message = 'User_id was not found';
/*     raise notice e'ERROR: User with u_id [%] wasn''t found',p_uid;*/
end;
$$;

alter procedure proc_generate_activation_code(integer) owner to test;

