create procedure validate_username(p_uname character varying)
    language plpgsql
as
$$
declare
begin
    case when not exists (select regexp_matches(p_uname,'^[a-zA-Z0-9._.-.+.]{6,20}$'))
        then raise exception
            using errcode = 'P3100',
                message = 'The username given does not meet the requirements.',
                hint = 'The username needs to be from 6 to 20 characters and contain only the following allowed characters:\nLetters from a to z (upper and lower case)\nNumbers from 0 to 9\nSpecial characters "_-+."';

        else
            null;
        end case; /*raises exception if username not matches regex*/
end;
$$;

alter procedure validate_username(varchar) owner to test;

