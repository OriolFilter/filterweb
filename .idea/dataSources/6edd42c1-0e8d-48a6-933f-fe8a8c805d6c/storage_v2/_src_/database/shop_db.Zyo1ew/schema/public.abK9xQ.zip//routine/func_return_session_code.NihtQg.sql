create function func_return_session_code(p_username character varying) returns character varying
    language plpgsql
as
$$
declare
    declare
    v_string varchar(60);
    v_uid integer;
begin
    if (func_check_user_exists(p_username)) then
        select into v_uid user_id from users where lower(username)=lower(p_username);
        select into v_string func_return_session_code(v_uid);
        return v_string;
    else
        raise exception
            using errcode = 'P6201',
                message = 'Username not found';
    end if;


end;
$$;

alter function func_return_session_code(varchar) owner to test;

