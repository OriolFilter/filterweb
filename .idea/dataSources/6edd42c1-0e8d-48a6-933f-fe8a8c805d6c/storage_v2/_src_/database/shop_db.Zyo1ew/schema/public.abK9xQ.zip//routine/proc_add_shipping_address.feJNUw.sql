create procedure proc_add_shipping_address(p_user_id integer, p_country character varying, p_city character varying, p_postalcode character varying, p_addline1 character varying, p_addline2 character varying DEFAULT NULL::character varying, p_addline3 character varying DEFAULT NULL::character varying)
    language plpgsql
as
$$
begin
    call check_shipping_country_code_name(p_country);
    call check_shipping_address_l1(p_addline1);
--     call check_shipping_address_l2(p_addline2);
--     call check_shipping_address_l3(p_addline3);
    insert into shipping_address(user_id,shipping_address_country,shipping_address_city,shipping_address_postal_code,shipping_address_line1,shipping_address_line2,shipping_address_line3)
                         values (p_user_id,upper(p_country),p_city,p_postalcode,p_addline1,p_addline2,p_addline3);
end;
$$;

alter procedure proc_add_shipping_address(integer, varchar, varchar, varchar, varchar, varchar, varchar) owner to test;

