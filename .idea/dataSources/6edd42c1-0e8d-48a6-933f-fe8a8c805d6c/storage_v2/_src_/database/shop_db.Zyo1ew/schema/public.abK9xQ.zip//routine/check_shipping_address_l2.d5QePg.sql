create procedure check_shipping_address_l2(p_name_method character varying)
    language plpgsql
as
$$
begin
    /* 5 - 200 chars - empty */
    if ((length(p_name_method::varchar) < 5 or length(p_name_method::varchar) > 200) and (not length(p_name_method::varchar) is null and not length(p_name_method::varchar) = 0) ) then
        raise exception
            using errcode = 'P3905',
                message = 'Shipping address line 2 field does not meet the requirements',
                hint = 'Shipping address line 2 needs to be from 5 to 200 or empty';
    end if;
end;
$$;

alter procedure check_shipping_address_l2(varchar) owner to test;

