create function func_return_session_token_from_credentials(p_uname character varying, p_pass character varying) returns character varying
    language plpgsql
as
$$
declare
        v_uid integer;
        v_token varchar;
begin
        call proc_credentials_user(p_uname,p_pass);
        select into v_uid user_id from users where lower(username)=lower(p_uname);
        call proc_check_user_is_activated(v_uid);
        /* Also checks user is activated*/
        select into v_token func_return_session_code(v_uid);
        update users set last_login=now() from users u,session_tokens s where u.user_id=v_uid; /* No need to check token is valid due proc */
        return v_token;

end;
$$;

alter function func_return_session_token_from_credentials(varchar, varchar) owner to test;

