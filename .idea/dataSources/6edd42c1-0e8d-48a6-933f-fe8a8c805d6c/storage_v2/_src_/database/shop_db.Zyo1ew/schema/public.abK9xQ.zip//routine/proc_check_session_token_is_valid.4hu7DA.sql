create procedure proc_check_session_token_is_valid(p_token character varying)
    language plpgsql
as
$$
begin
    case when exists(select true from session_tokens where session_token=p_token)
        then null;
        else
            raise exception
                using errcode = 'P6301',
                    message = 'Token not valid';
        end case; /* Podria fer-ho tot junt pero llavors no tendria ni la meitat de respostes */
    case when exists(select true from session_tokens where session_token=p_token and created_on<now() and expires_on>now())
        then null;
        else
            raise exception
                using errcode = 'P6303',
                    message = 'Token expired';
        end case;
end;
$$;

alter procedure proc_check_session_token_is_valid(varchar) owner to test;

