create function func_return_shipping_address_from_stoken(p_stoken character varying)
    returns TABLE(sa_row_number integer, sa_country character varying, sa_city character varying, sa_postal_code character varying, sa_line1 character varying, sa_line2 character varying, sa_line3 character varying)
    language plpgsql
as
$$
declare
    v_uid integer;
begin
    call proc_check_session_token_is_valid(p_stoken);
    select into v_uid user_id from session_tokens where p_stoken=session_token;
    return query SELECT row_number() over (order by shipping_address_id)::integer, shipping_address_country::varchar,shipping_address_city::varchar, shipping_address_postal_code::varchar,shipping_address_line1::varchar,shipping_address_line2::varchar,shipping_address_line3::varchar from shipping_address where user_id=v_uid;
--     return query SELECT row_number() over (order by user_payment_method_id)::integer,user_payment_method_name from user_payment_methods where user_id=v_uid;
end;
$$;

alter function func_return_shipping_address_from_stoken(varchar) owner to test;

