create procedure check_shipping_address_l1(p_name_method character varying)
    language plpgsql
as
$$
begin
    /* 5 - 200 chars */
    if (length(p_name_method) < 5 or length(p_name_method) > 200) then
        raise exception
            using errcode = 'P3904',
                message = 'Shipping address line 1 field does not meet the requirements',
                hint = 'Shipping address line 1 needs to be from 5 to 200';
    end if;
end;
$$;

alter procedure check_shipping_address_l1(varchar) owner to test;

