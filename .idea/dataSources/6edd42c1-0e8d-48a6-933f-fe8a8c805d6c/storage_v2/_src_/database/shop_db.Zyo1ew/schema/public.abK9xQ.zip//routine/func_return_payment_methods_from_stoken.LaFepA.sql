create function func_return_payment_methods_from_stoken(p_stoken character varying)
    returns TABLE(payment_method_row_number integer, payment_method_name character varying)
    language plpgsql
as
$$
declare
        v_uid integer;
    begin
        call proc_check_session_token_is_valid(p_stoken);
        select into v_uid user_id from session_tokens where p_stoken=session_token;
        return query SELECT row_number() over (order by user_payment_method_id)::integer,user_payment_method_name from user_payment_methods where user_id=v_uid;
    end;
$$;

alter function func_return_payment_methods_from_stoken(varchar) owner to test;

