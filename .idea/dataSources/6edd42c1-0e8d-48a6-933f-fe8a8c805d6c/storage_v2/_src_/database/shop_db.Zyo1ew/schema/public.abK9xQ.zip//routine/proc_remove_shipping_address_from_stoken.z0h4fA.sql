create procedure proc_remove_shipping_address_from_stoken(p_stoken character varying, p_row_number integer)
    language plpgsql
as
$$
declare
    v_uid integer;
    v_said integer; /* payment method id */
begin
    call proc_check_session_token_is_valid(p_stoken);
    select into v_uid user_id from session_tokens where p_stoken=session_token;

    select sq.pmid into v_said from (SELECT row_number() over (order by shipping_address_id)::integer as rn, shipping_address_id as pmid from shipping_address where user_id=v_uid)
                                        as sq where sq.rn::integer=p_row_number::integer;

    delete from shipping_address where shipping_address_id::integer=v_said::integer;
end;
$$;

alter procedure proc_remove_shipping_address_from_stoken(varchar, integer) owner to test;

