create procedure validate_mail(p_mail character varying)
    language plpgsql
as
$$
declare
    v_mail bool;
begin
    case when not exists (
            select regexp_matches(p_mail,'^[a-zA-Z0-9.!#$%&''*+=?^_`{|}~-]+@[a-zA-Z10-9-]+\.[a-zA-Z0-9-]+$')) then
        raise exception
            using errcode = 'P3300',
                message = 'The email given does not meet the requirements.',
                hint = 'Email seems to be invalid';
        else null;
        end case ; /* not raises exception if email matches regex */
    /* text@text.text */
end;
$$;

alter procedure validate_mail(varchar) owner to test;

