create procedure proc_generate_activation_code(p_username character varying)
    language plpgsql
as
$$
declare
    v_uid integer;
begin
    /*get uid then call the other command*/
    case when not exists(select user_id from users where lower(username)=lower(p_username))
        then raise exception
            using errcode = 'P6210',
                message = 'The given username wasn''t found';
        else
            select into v_uid user_id from users where lower(username)=lower(p_username);
        end case;
    call proc_generate_activation_code(v_uid);

end;
$$;

alter procedure proc_generate_activation_code(varchar) owner to test;

