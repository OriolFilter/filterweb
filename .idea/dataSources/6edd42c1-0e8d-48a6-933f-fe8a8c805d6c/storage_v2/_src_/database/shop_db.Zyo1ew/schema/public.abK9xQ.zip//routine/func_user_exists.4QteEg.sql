create function func_user_exists(p_uname character varying) returns boolean
    language plpgsql
as
$$
begin
    case when exists(select lower(username) from users where lower(username)=lower(p_uname))
        then return true;
        else return false;
    end case;
end;
$$;

alter function func_user_exists(varchar) owner to test;

