create procedure proc_check_login(p_uname character varying, p_passwd character varying)
    language plpgsql
as
$$
declare
BEGIN
    case when not exists (select from users where lower(username)=lower(p_uname) and password=crypt(p_passwd,password))
        then raise exception
                      using errcode = 'P9000',
                      message = 'Invalid Credentials';
        else null;
    end case;


END;
$$;

alter procedure proc_check_login(varchar, varchar) owner to test;

