create function func_return_change_password_code(p_uid integer) returns character varying
    language plpgsql
as
$$
declare
    v_string varchar(60);
begin
    /* uses u_id*/

    /* Generates and insert token*/
    select into v_string random_string(60);
    while (select true from change_password_tokens where change_password_token=v_string) loop
            select into v_string random_string(60);
        end loop;
    insert into change_password_tokens(user_id,change_password_token) values(p_uid,v_string);
    return v_string;
exception
    when sqlstate '23503' then
        raise exception
            using errcode = 'P62200',
                message = 'User_id was not found';
--         raise notice e'ERROR: User with u_id [%] wasn''t found',p_uid;
end;
$$;

alter function func_return_change_password_code(integer) owner to test;

