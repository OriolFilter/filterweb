create procedure proc_remove_payment_method_from_stoken(p_stoken character varying, p_row_number integer)
    language plpgsql
as
$$
declare
    v_uid integer;
    v_pmid integer; /* payment method id */
begin
    call proc_check_session_token_is_valid(p_stoken);
    select into v_uid user_id from session_tokens where p_stoken=session_token;

    select sq.pmid into v_pmid from (SELECT row_number() over (order by user_payment_method_id)::integer as rn, user_payment_method_id as pmid from user_payment_methods where user_id=v_uid)
                                   as sq where sq.rn::integer=p_row_number::integer;
    delete from user_payment_methods where user_payment_method_id::integer=v_pmid::integer;
/*    then raise exception
        using errcode = 'P6205',
                        message = 'Payment method not found',
                        hint = 'Payment method not found';

    else
    null;
end case;*/
/*    delete from user_payment_methods where user_payment_method_id=(
        select sq.upd as pmid from (
            SELECT row_number() over (order by user_payment_method_id)::integer as rn, user_payment_method_id as upd from user_payment_methods where user_id=22)
            as sq where sq.rn=p_row_number); /* one line */*/

--     delete from user_payment_methods where user_payment_method_id=(SELECT user_payment_method_id from user_payment_methods where user_id=v_uid and p_row_number=row_number() over (order by user_payment_method_id) );
end;
$$;

alter procedure proc_remove_payment_method_from_stoken(varchar, integer) owner to test;

