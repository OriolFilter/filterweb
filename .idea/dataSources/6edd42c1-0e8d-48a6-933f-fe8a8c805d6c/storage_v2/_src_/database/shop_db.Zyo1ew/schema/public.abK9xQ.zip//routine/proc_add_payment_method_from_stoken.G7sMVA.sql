create procedure proc_add_payment_method_from_stoken(p_stoken integer, p_name_method character varying)
    language plpgsql
as
$$
declare
        v_uid integer;
begin
    select into v_uid user_id from session_tokens where p_stoken=user_id;
    insert into user_payment_methods(user_id,user_payment_method_name) values (v_uid,p_name_method);
end;
$$;

alter procedure proc_add_payment_method_from_stoken(integer, varchar) owner to test;

