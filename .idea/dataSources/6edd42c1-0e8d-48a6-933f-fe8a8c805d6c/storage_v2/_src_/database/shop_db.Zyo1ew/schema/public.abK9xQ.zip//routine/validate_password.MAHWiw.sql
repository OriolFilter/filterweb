create procedure validate_password(p_passwd character varying)
    language plpgsql
as
$$
declare
begin
    /* Add must contain one of the followings! */
    case when not exists (
            select regexp_matches(p_passwd,'^[a-zA-Z0-9$%.,?!+_=-]{6,20}$')
        )
        then
--         raise exception 'not_valid_email';
            raise exception
                using errcode = 'P3200',
                    message = 'The password given does not meet the requirements.',
                    hint = 'The password needs to be from 6 to 20 characters and contain only the following allowed characters:\nLetters from a to z (upper and lower case)\nNumbers from 0 to 9\nSpecial characters "$%/.,?!+_=-"';

        else null;
        end case ; /*raises exception if password not matches regex*/
    /* text@text.text */
end;
$$;

alter procedure validate_password(varchar) owner to test;

