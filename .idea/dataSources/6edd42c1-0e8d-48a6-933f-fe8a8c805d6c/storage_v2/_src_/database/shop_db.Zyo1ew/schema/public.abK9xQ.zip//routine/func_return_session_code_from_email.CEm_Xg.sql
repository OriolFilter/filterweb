create function func_return_session_code_from_email(p_email character varying) returns character varying
    language plpgsql
as
$$
declare
    v_string varchar(60);
    v_user varchar;
begin
    if (func_check_email_exists(p_email)) then
        select into v_user username from users where lower(email)=lower(p_email);
        select into v_string func_return_session_code(v_user);
        return v_string;
    else
        raise exception
            using errcode = 'P6203',
                message = 'Email not found';
    end if;
end;

$$;

alter function func_return_session_code_from_email(varchar) owner to test;

