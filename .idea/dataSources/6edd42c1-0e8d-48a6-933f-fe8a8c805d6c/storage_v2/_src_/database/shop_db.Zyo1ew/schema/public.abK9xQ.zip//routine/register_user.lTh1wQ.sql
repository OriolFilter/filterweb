create procedure register_user(p_username character varying, p_passwd character varying, p_email character varying)
    language plpgsql
as
$$
declare
--     not_valid_email exception;
    v_uid integer;
BEGIN
    call validate_username(p_username);
    call validate_password(p_passwd);
    call validate_mail(p_email);
--  Check if entries already exists
    call proc_check_user_exists(p_username);
    call proc_check_email_exists(p_email);
    /*
/*    case when exists(select true from users where username=p_username)
        then raise exception
            using errcode = 'P6101',
                message = 'This username is already in use';
        else null;
        end case;*/
--     case when exists(select true from users where email=cast(encode(cast(p_email as bytea),'hex') as bytea))
    /*
    case when exists(select true from users where email=p_email)
        then raise exception
            using errcode = 'P6102',
                message = 'This email is already in use';
        else null;
        end case;
    */*/
--     insert into users(username, password, email) values (p_username,crypt(p_passwd, gen_salt('bf',8)),cast(encode(cast(p_email as bytea),'hex') as bytea));
    insert into users(username, password, email) values (p_username,crypt(p_passwd, gen_salt('bf',8)),p_email);
    select into v_uid user_id from users where lower(username)=lower(p_username);
    insert into activated_accounts(user_id) values (v_uid); /* Canviar a trigger */

END;

$$;

alter procedure register_user(varchar, varchar, varchar) owner to test;

