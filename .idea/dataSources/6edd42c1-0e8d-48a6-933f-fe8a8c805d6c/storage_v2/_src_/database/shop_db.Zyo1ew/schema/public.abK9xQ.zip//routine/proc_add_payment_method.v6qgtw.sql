create procedure proc_add_payment_method(p_user_id integer, p_name_method character varying)
    language plpgsql
as
$$
begin
        call check_payment_method_name(p_name_method);
        insert into user_payment_methods(user_id,user_payment_method_name) values (p_user_id,p_name_method);
    end;
$$;

alter procedure proc_add_payment_method(integer, varchar) owner to test;

