create procedure proc_check_user_is_activated(p_uid integer)
    language plpgsql
as
$$
begin
    case when not exists(select true from activated_accounts where user_id=p_uid and activated_bool=true)
        then raise exception
            using errcode = 'P7100',
                message = 'This account is not activated';
        else null;
        end case;
end;
$$;

alter procedure proc_check_user_is_activated(integer) owner to test;

