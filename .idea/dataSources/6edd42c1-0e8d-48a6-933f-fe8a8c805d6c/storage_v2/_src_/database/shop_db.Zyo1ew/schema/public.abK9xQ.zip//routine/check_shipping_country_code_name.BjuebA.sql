create procedure check_shipping_country_code_name(p_name_method character varying)
    language plpgsql
as
$$
begin
    /* check 2 chars and chars */
    case when not exists (select regexp_matches(p_name_method,'^[a-zA-Z]{2}$'))
        then raise exception
            using errcode = 'P3901',
                message = 'Shipping address country does not meet the requirements',
                hint = 'Shipping address country needs to be 2 characters that represent the country following the standar ISO 3166-2';
        else
            null;
        end case; /*raises exception if name not matches regex*/
end;
$$;

alter procedure check_shipping_country_code_name(varchar) owner to test;

