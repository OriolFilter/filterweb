create function func_credentials_user(p_uname character varying, p_passwd character varying) returns boolean
    language plpgsql
as
$$
declare
    user_found boolean;
BEGIN
    select into user_found (case when exists (select from users where lower(username)=lower(p_uname) and password=crypt(p_passwd,password))
                                     then 1
                                 else 0
        end) as found;
    RETURN user_found;
END;
$$;

alter function func_credentials_user(varchar, varchar) owner to test;

