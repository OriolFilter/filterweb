create procedure proc_add_shipping_address_from_stoken(p_stoken character varying, p_country character varying, p_city character varying, p_postalcode character varying, p_addline1 character varying, p_addline2 character varying DEFAULT NULL::character varying, p_addline3 character varying DEFAULT NULL::character varying)
    language plpgsql
as
$$
declare
    v_uid integer;
begin
    call proc_check_session_token_is_valid(p_stoken);
    call check_shipping_country_code_name(p_country);
    call check_shipping_address_l1(p_addline1);
--     call check_shipping_address_l2(p_addline2);
--     call check_shipping_address_l3(p_addline3);
    select into v_uid user_id from session_tokens where p_stoken=session_token;
    insert into shipping_address(user_id,shipping_address_country,shipping_address_city,shipping_address_postal_code,shipping_address_line1,shipping_address_line2,shipping_address_line3)
                         values (v_uid,upper(p_country),p_city,p_postalcode,p_addline1,p_addline2,p_addline3);
end;
$$;

alter procedure proc_add_shipping_address_from_stoken(varchar, varchar, varchar, varchar, varchar, varchar, varchar) owner to test;

