create procedure proc_enlarge_login(p_token character varying)
    language plpgsql
as
$$
declare
BEGIN
    /* no control*/
    /* Extends login by 30 mins */
    update session_tokens set expires_on=now() + '30 minute'::interval where session_token=p_token and expires_on<now() + '30 minute'::interval;
END;
$$;

alter procedure proc_enlarge_login(varchar) owner to test;

