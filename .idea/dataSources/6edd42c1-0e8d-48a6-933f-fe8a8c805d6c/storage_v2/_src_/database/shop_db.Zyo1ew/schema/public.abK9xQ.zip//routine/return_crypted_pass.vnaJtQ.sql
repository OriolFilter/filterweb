create function return_crypted_pass(v_txt character varying) returns character varying
    language plpgsql
as
$$
begin
        return crypt(v_txt, gen_salt('bf',8));
    end;
$$;

alter function return_crypted_pass(varchar) owner to test;

