create procedure check_payment_method_name(p_name_method character varying)
    language plpgsql
as
$$
begin
            case when not exists (select regexp_matches(p_name_method,'^[a-zA-Z0-9_ ]{6,20}$'))
                then raise exception
                    using errcode = 'P3600',
                        message = 'Payment method info does not meet the requirements',
                        hint = 'Payment method name needs to be from 6 to 20 characters and contain only the following allowed characters:\nLetters from a to z (upper and lower case)\nNumbers from 0 to 9 and/or spaces or _';
                else
                    null;
                end case; /*raises exception if name not matches regex*/
        end;
$$;

alter procedure check_payment_method_name(varchar) owner to test;

