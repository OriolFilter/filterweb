create function func_email_exists(p_email character varying) returns boolean
    language plpgsql
as
$$
begin
    case when exists(select lower(email) from users where lower(email)=lower(p_email))
        then return true;
        else return false;
    end case;
end;
$$;

alter function func_email_exists(varchar) owner to test;

