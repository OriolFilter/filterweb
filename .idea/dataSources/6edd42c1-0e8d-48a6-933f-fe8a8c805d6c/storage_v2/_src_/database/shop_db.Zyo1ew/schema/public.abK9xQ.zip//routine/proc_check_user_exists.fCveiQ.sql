create procedure proc_check_user_exists(p_uname character varying)
    language plpgsql
as
$$
begin
    case when exists(select lower(username) from users where lower(username)=lower(p_uname))
        then raise exception
            using errcode = 'P6101',
                message = 'This username is already in use';
        else null;
    end case;
end;
$$;

alter procedure proc_check_user_exists(varchar) owner to test;

