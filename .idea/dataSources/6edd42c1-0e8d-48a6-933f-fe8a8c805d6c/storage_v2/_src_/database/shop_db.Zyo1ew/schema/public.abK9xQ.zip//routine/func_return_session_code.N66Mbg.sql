create function func_return_session_code(p_uid integer) returns character varying
    language plpgsql
as
$$
declare
    v_string varchar(60);
begin
    /* uses u_id*/

    /* Generates and insert token*/
    select into v_string random_string(60);
    while (select true from session_tokens where session_token=v_string) loop
            select into v_string random_string(60);
        end loop;
    insert into session_tokens(user_id,session_token) values(p_uid,v_string);
    return v_string;
exception
    when sqlstate '23503' then
        raise exception
            using errcode = 'P62200',
                message = 'User_id was not found';
end;
$$;

alter function func_return_session_code(integer) owner to test;

