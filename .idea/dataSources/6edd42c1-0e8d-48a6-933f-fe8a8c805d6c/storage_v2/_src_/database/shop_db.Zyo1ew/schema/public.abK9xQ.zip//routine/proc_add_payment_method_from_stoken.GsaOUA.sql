create procedure proc_add_payment_method_from_stoken(p_stoken character varying, p_name_method character varying)
    language plpgsql
as
$$
declare
        v_uid integer;
begin
    call proc_check_session_token_is_valid(p_stoken);
    call check_payment_method_name(p_name_method);
    select into v_uid user_id from session_tokens where p_stoken=session_token;
    insert into user_payment_methods(user_id,user_payment_method_name) values (v_uid,p_name_method);
end;
$$;

alter procedure proc_add_payment_method_from_stoken(varchar, varchar) owner to test;

