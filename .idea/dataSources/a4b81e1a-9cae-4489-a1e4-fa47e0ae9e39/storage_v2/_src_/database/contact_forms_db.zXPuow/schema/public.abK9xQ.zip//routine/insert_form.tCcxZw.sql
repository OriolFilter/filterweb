create procedure insert_form(p_name character varying, p_email character varying, p_text text)
    language plpgsql
as
$$
begin
    case when not exists (
            select regexp_matches(p_name,'^[\w0-9 ]{4,40}$')) then
        raise exception
            using errcode = 'P3400',
                message = 'The name given does not meet the requirements.',
                hint = 'Name must be from 4 to 40 characters from the english alphabet or numbers, (spaces allowed)';
        else null;
    end case ;
    case when not exists (
        select regexp_matches(p_email,'^[a-zA-Z0-9.!#$%&''*+=?^_`{|}~-]+@[a-zA-Z10-9-]+\.[a-zA-Z0-9-]+$')) then
    raise exception
        using errcode = 'P3300',
            message = 'The email given does not meet the requirements.',
            hint = 'Email seems to be invalid';
    else null;
    end case ;
    if (length(p_text) < 20 or length(p_text) > 400) then
        raise exception
            using errcode = 'P3500',
                message = 'The text given does not meet the requirements.',
                hint = 'Text message must be from 20 to 400 characters';
    end if;
    insert into forms_table(name, email,text) values (p_name,p_email,p_text);
end;
$$;

alter procedure insert_form(varchar, varchar, text) owner to test;

grant execute on procedure insert_form(p_name character varying, p_email character varying, p_text text) to form_user;

